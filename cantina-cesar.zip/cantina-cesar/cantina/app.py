"""Raiz de composição: o ÚNICO lugar que conhece as classes concretas."""
from .adaptadores.notificadores import NotificadorConsole
from .adaptadores.pagamentos import CarteiraPrePaga, PagamentoPix
from .adaptadores.repositorio_memoria import RepositorioEmMemoria
from .dominio.cardapio import Cardapio
from .dominio.produto import Combo, Item
from .servicos.estimador import EstimadorDeFila
from .servicos.servico_pedidos import ServicoDePedidos


def cardapio_do_dia() -> Cardapio:
    coxinha = Item("Coxinha", 750, minutos_preparo=3)
    pao_queijo = Item("Pão de queijo", 500, minutos_preparo=2)
    tapioca = Item("Tapioca de queijo coalho", 1000, minutos_preparo=5)
    suco = Item("Suco de cajá", 600, minutos_preparo=1)
    cafe = Item("Café", 350, minutos_preparo=1)

    c = Cardapio()
    c.adicionar("1", coxinha)
    c.adicionar("2", pao_queijo)
    c.adicionar("3", tapioca)
    c.adicionar("4", suco)
    c.adicionar("5", cafe)
    c.adicionar("6", Combo("Combo Intervalo (coxinha + suco)", [coxinha, suco], desconto_centavos=150))
    c.adicionar("7", Combo("Combo Café da Manhã (pão de queijo + café)", [pao_queijo, cafe], 100))
    return c


def montar_servico() -> ServicoDePedidos:
    return ServicoDePedidos(
        cardapio=cardapio_do_dia(),
        repositorio=RepositorioEmMemoria(),
        meios_de_pagamento={"pix": PagamentoPix(), "carteira": CarteiraPrePaga(2000)},
        notificador=NotificadorConsole(),
        estimador=EstimadorDeFila(atendentes=2),
    )

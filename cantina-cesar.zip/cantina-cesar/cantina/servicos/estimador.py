import math
from typing import List

from ..dominio.pedido import Pedido


class EstimadorDeFila:
    """Responsabilidade única: calcular quanto falta para um pedido ficar pronto."""

    def __init__(self, atendentes: int = 2):
        if atendentes < 1:
            raise ValueError("Precisa de pelo menos 1 atendente")
        self._atendentes = atendentes

    def estimar(self, fila: List[Pedido], pedido: Pedido) -> int:
        if pedido not in fila:
            return 0
        posicao = fila.index(pedido)
        trabalho = sum(p.tempo_preparo() for p in fila[: posicao + 1])
        return math.ceil(trabalho / self._atendentes)

from typing import Dict, List, Tuple

from ..dominio.cardapio import Cardapio
from ..dominio.dinheiro import formatar
from ..dominio.pedido import Pedido, Status
from ..dominio.produto import Produto
from ..portas import MeioDePagamento, Notificador, RepositorioDePedidos
from ..visoes import VisaoCliente, VisaoCozinha
from .estimador import EstimadorDeFila


class PedidoNaoEncontrado(Exception):
    pass


class PagamentoRecusado(Exception):
    pass


class ServicoDePedidos(VisaoCliente, VisaoCozinha):
    """Orquestra o caso de uso. Depende só de abstrações, todas injetadas."""

    def __init__(
        self,
        cardapio: Cardapio,
        repositorio: RepositorioDePedidos,
        meios_de_pagamento: Dict[str, MeioDePagamento],
        notificador: Notificador,
        estimador: EstimadorDeFila,
    ):
        self._cardapio = cardapio
        self._repo = repositorio
        self._meios = meios_de_pagamento
        self._notificador = notificador
        self._estimador = estimador
        self._proxima_senha = 1

    # ---------- VisaoCliente ----------
    def cardapio(self) -> List[Tuple[str, Produto]]:
        return self._cardapio.listar()

    def meios_disponiveis(self) -> List[str]:
        return list(self._meios)

    def fazer_pedido(self, itens: Dict[str, int]) -> Pedido:
        linhas = [(self._cardapio.buscar(cod), qtd) for cod, qtd in itens.items()]
        pedido = Pedido(self._gerar_senha(), linhas)
        self._repo.salvar(pedido)
        return pedido

    def pagar(self, senha: str, meio: str) -> int:
        pedido = self._buscar(senha)
        if meio not in self._meios:
            raise ValueError(f"Meio de pagamento '{meio}' não aceito")
        if not self._meios[meio].cobrar(pedido.total(), senha):
            raise PagamentoRecusado(f"Pagamento via {meio} recusado")
        pedido.confirmar_pagamento()
        self._repo.salvar(pedido)
        minutos = self._estimar(pedido)
        self._notificador.notificar(
            senha, f"Pagamento de {formatar(pedido.total())} confirmado. Pronto em ~{minutos} min."
        )
        return minutos

    def consultar(self, senha: str) -> Tuple[Status, int]:
        pedido = self._buscar(senha)
        return pedido.status, self._estimar(pedido)

    # ---------- VisaoCozinha ----------
    def fila(self) -> List[Pedido]:
        return self._repo.em_fila()

    def avancar(self, senha: str) -> Status:
        pedido = self._buscar(senha)
        acoes = {
            Status.RECEBIDO: pedido.iniciar_preparo,
            Status.EM_PREPARO: pedido.marcar_pronto,
            Status.PRONTO: pedido.retirar,
        }
        acao = acoes.get(pedido.status)
        if acao is None:
            raise ValueError(f"Pedido {senha} não pode avançar (status: {pedido.status.value})")
        acao()
        self._repo.salvar(pedido)
        if pedido.status is Status.PRONTO:
            self._notificador.notificar(senha, "Seu lanche está pronto! Pode retirar no balcão.")
        return pedido.status

    # ---------- internos ----------
    def _buscar(self, senha: str) -> Pedido:
        pedido = self._repo.buscar(senha)
        if pedido is None:
            raise PedidoNaoEncontrado(f"Senha {senha} não encontrada")
        return pedido

    def _estimar(self, pedido: Pedido) -> int:
        return self._estimador.estimar(self._repo.em_fila(), pedido)

    def _gerar_senha(self) -> str:
        senha = f"{self._proxima_senha:03d}"
        self._proxima_senha += 1
        return senha

"""Abstrações das quais o núcleo depende (Inversão de Dependências).

O serviço conhece só estas interfaces; as implementações concretas
ficam em cantina/adaptadores e são injetadas em cantina/app.py.
"""
from abc import ABC, abstractmethod
from typing import List, Optional

from .dominio.pedido import Pedido


class RepositorioDePedidos(ABC):
    @abstractmethod
    def salvar(self, pedido: Pedido) -> None: ...

    @abstractmethod
    def buscar(self, senha: str) -> Optional[Pedido]: ...

    @abstractmethod
    def em_fila(self) -> List[Pedido]:
        """Pedidos pagos ainda não prontos, em ordem de chegada."""


class MeioDePagamento(ABC):
    @abstractmethod
    def cobrar(self, valor_centavos: int, referencia: str) -> bool:
        """Contrato: retorna True se aprovado, False se recusado. Nunca lança por recusa."""


class Notificador(ABC):
    @abstractmethod
    def notificar(self, senha: str, mensagem: str) -> None: ...

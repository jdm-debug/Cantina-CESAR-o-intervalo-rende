from enum import Enum
from typing import List, Sequence, Tuple

from .produto import Produto


class Status(Enum):
    AGUARDANDO_PAGAMENTO = "aguardando pagamento"
    RECEBIDO = "recebido"
    EM_PREPARO = "em preparo"
    PRONTO = "pronto para retirada"
    RETIRADO = "retirado"


class TransicaoInvalida(Exception):
    pass


# Ocultamento de informação: as regras de transição ficam escondidas neste módulo.
_TRANSICOES = {
    Status.AGUARDANDO_PAGAMENTO: {Status.RECEBIDO},
    Status.RECEBIDO: {Status.EM_PREPARO},
    Status.EM_PREPARO: {Status.PRONTO},
    Status.PRONTO: {Status.RETIRADO},
    Status.RETIRADO: set(),
}


class Pedido:
    def __init__(self, senha: str, itens: Sequence[Tuple[Produto, int]]):
        if not itens:
            raise ValueError("Pedido vazio")
        if any(qtd <= 0 for _, qtd in itens):
            raise ValueError("Quantidade deve ser positiva")
        self._senha = senha
        self._itens = tuple(itens)
        self._status = Status.AGUARDANDO_PAGAMENTO

    # --- leitura (sem setters públicos) ---
    @property
    def senha(self) -> str:
        return self._senha

    @property
    def status(self) -> Status:
        return self._status

    # Demeter: quem usa o pedido pergunta o total a ele, não navega pelos itens.
    def total(self) -> int:
        return sum(produto.preco() * qtd for produto, qtd in self._itens)

    def tempo_preparo(self) -> int:
        return max(produto.tempo_preparo() for produto, _ in self._itens)

    def resumo(self) -> List[str]:
        return [f"{qtd}x {produto.nome}" for produto, qtd in self._itens]

    def esta_na_fila(self) -> bool:
        return self._status in (Status.RECEBIDO, Status.EM_PREPARO)

    # --- única forma de mudar o estado ---
    def confirmar_pagamento(self) -> None:
        self._mudar_para(Status.RECEBIDO)

    def iniciar_preparo(self) -> None:
        self._mudar_para(Status.EM_PREPARO)

    def marcar_pronto(self) -> None:
        self._mudar_para(Status.PRONTO)

    def retirar(self) -> None:
        self._mudar_para(Status.RETIRADO)

    def _mudar_para(self, novo: Status) -> None:
        if novo not in _TRANSICOES[self._status]:
            raise TransicaoInvalida(
                f"Pedido {self._senha}: não pode ir de '{self._status.value}' para '{novo.value}'"
            )
        self._status = novo

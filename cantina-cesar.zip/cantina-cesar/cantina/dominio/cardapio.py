from typing import Dict, List, Tuple

from .produto import Produto


class ProdutoIndisponivel(Exception):
    pass


class Cardapio:
    """Responsabilidade única: saber o que está à venda hoje."""

    def __init__(self):
        self._produtos: Dict[str, Produto] = {}

    def adicionar(self, codigo: str, produto: Produto) -> None:
        self._produtos[codigo] = produto

    def buscar(self, codigo: str) -> Produto:
        try:
            return self._produtos[codigo]
        except KeyError:
            raise ProdutoIndisponivel(f"Código '{codigo}' não está no cardápio de hoje")

    def listar(self) -> List[Tuple[str, Produto]]:
        return list(self._produtos.items())

"""Tudo o que pode ser vendido na cantina: itens avulsos e combos."""
from dataclasses import dataclass
from typing import Protocol, Sequence


class Produto(Protocol):
    """Contrato comum. Pedido e Cardápio só conhecem esta abstração."""

    nome: str

    def preco(self) -> int: ...

    def tempo_preparo(self) -> int: ...


@dataclass(frozen=True)
class Item:
    nome: str
    preco_centavos: int
    minutos_preparo: int = 0

    def __post_init__(self):
        if self.preco_centavos < 0 or self.minutos_preparo < 0:
            raise ValueError("Preço e tempo de preparo não podem ser negativos")

    def preco(self) -> int:
        return self.preco_centavos

    def tempo_preparo(self) -> int:
        return self.minutos_preparo


class Combo:
    """Composição em vez de herança: um Combo CONTÉM produtos, não É um Item."""

    def __init__(self, nome: str, produtos: Sequence[Produto], desconto_centavos: int = 0):
        if not produtos:
            raise ValueError("Combo precisa de ao menos um produto")
        self.nome = nome
        self._produtos = tuple(produtos)
        self._desconto = desconto_centavos

    def preco(self) -> int:
        bruto = sum(p.preco() for p in self._produtos)
        return max(0, bruto - self._desconto)

    def tempo_preparo(self) -> int:
        # os itens de um combo são preparados em paralelo
        return max(p.tempo_preparo() for p in self._produtos)

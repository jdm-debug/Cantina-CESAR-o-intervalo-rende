"""Valores monetários são guardados em centavos (int) para evitar erros de float."""


def formatar(centavos: int) -> str:
    reais, cents = divmod(centavos, 100)
    return f"R$ {reais},{cents:02d}"

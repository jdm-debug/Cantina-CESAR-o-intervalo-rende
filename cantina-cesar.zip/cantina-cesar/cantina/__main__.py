"""Interface de terminal. Cada tela depende só da visão de que precisa."""
import sys

from .app import montar_servico
from .dominio.dinheiro import formatar
from .visoes import VisaoCliente, VisaoCozinha


def mostrar_cardapio(cliente: VisaoCliente) -> None:
    print("\n📋 Cardápio de hoje")
    for codigo, produto in cliente.cardapio():
        print(f"  [{codigo}] {produto.nome:<45} {formatar(produto.preco()):>9}  (~{produto.tempo_preparo()} min)")


def tela_pedido(cliente: VisaoCliente, meios: list) -> None:
    mostrar_cardapio(cliente)
    entrada = input("\nItens (ex: 1x2, 4x1): ").strip()
    try:
        itens = {}
        for parte in entrada.split(","):
            cod, qtd = parte.strip().split("x")
            itens[cod.strip()] = itens.get(cod.strip(), 0) + int(qtd)
        pedido = cliente.fazer_pedido(itens)
        print(f"\n🧾 Pedido {pedido.senha}: {', '.join(pedido.resumo())} = {formatar(pedido.total())}")
        meio = input(f"Pagar com ({'/'.join(meios)}): ").strip().lower()
        minutos = cliente.pagar(pedido.senha, meio)
        print(f"✅ Senha {pedido.senha}. Chegue no balcão em ~{minutos} min, sem fila.")
    except Exception as erro:
        print(f"⚠️  {erro}")


def tela_consulta(cliente: VisaoCliente) -> None:
    try:
        status, minutos = cliente.consultar(input("Senha: ").strip())
        print(f"Status: {status.value}" + (f" (~{minutos} min)" if minutos else ""))
    except Exception as erro:
        print(f"⚠️  {erro}")


def tela_cozinha(cozinha: VisaoCozinha) -> None:
    fila = cozinha.fila()
    print("\n👩‍🍳 Fila da cozinha")
    if not fila:
        print("  (vazia)")
    for p in fila:
        print(f"  {p.senha} | {p.status.value:<12} | {', '.join(p.resumo())}")
    senha = input("Senha para avançar (enter para voltar): ").strip()
    if senha:
        try:
            print(f"→ {senha}: {cozinha.avancar(senha).value}")
        except Exception as erro:
            print(f"⚠️  {erro}")


def menu() -> None:
    servico = montar_servico()
    opcoes = {
        "1": lambda: mostrar_cardapio(servico),
        "2": lambda: tela_pedido(servico, servico.meios_disponiveis()),
        "3": lambda: tela_consulta(servico),
        "4": lambda: tela_cozinha(servico),
    }
    while True:
        print("\n=== 🍔 Cantina CESAR: o intervalo rende ===")
        print("1) Ver cardápio   2) Fazer pedido   3) Consultar senha   4) [Cozinha] Fila   0) Sair")
        escolha = input("> ").strip()
        if escolha == "0":
            break
        opcoes.get(escolha, lambda: print("Opção inválida"))()


def demo() -> None:
    """Roteiro automático, útil para gravar o vídeo."""
    servico = montar_servico()
    mostrar_cardapio(servico)
    print("\n▶ Ana pede no início da aula: Combo Intervalo + Tapioca, paga no Pix")
    ana = servico.fazer_pedido({"6": 1, "3": 1})
    servico.pagar(ana.senha, "pix")
    print("▶ Bruno pede 2 pães de queijo e paga com a carteira")
    bruno = servico.fazer_pedido({"2": 2})
    servico.pagar(bruno.senha, "carteira")
    print("▶ Caio tenta pagar 3 tapiocas com a carteira (saldo restante insuficiente)")
    caio = servico.fazer_pedido({"3": 3})
    try:
        servico.pagar(caio.senha, "carteira")
    except Exception as erro:
        print(f"  ⚠️  {erro}. Caio paga no Pix:")
        servico.pagar(caio.senha, "pix")
    print("\n▶ Cozinha trabalha a fila")
    for p in servico.fila():
        print(f"  {p.senha} | {', '.join(p.resumo())}")
    servico.avancar(ana.senha)
    servico.avancar(ana.senha)
    print(f"▶ Bruno consulta: {servico.consultar(bruno.senha)[0].value}, ~{servico.consultar(bruno.senha)[1]} min")
    servico.avancar(ana.senha)
    print(f"▶ Ana retirou. Status: {servico.consultar(ana.senha)[0].value}")


if __name__ == "__main__":
    demo() if "--demo" in sys.argv else menu()

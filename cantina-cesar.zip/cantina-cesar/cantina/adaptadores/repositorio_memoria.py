from typing import Dict, List, Optional

from ..dominio.pedido import Pedido
from ..portas import RepositorioDePedidos


class RepositorioEmMemoria(RepositorioDePedidos):
    """PoC sem banco. Trocar por SQLite/Postgres = nova classe, serviço intacto."""

    def __init__(self):
        self._pedidos: Dict[str, Pedido] = {}  # dict preserva a ordem de chegada

    def salvar(self, pedido: Pedido) -> None:
        self._pedidos[pedido.senha] = pedido

    def buscar(self, senha: str) -> Optional[Pedido]:
        return self._pedidos.get(senha)

    def em_fila(self) -> List[Pedido]:
        return [p for p in self._pedidos.values() if p.esta_na_fila()]

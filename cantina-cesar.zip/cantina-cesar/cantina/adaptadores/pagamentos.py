"""Aberto/Fechado + Liskov: cada meio é uma classe nova que respeita o mesmo contrato."""
from ..portas import MeioDePagamento


class PagamentoPix(MeioDePagamento):
    """Simulado: sempre aprova (na PoC não integramos com banco)."""

    def cobrar(self, valor_centavos: int, referencia: str) -> bool:
        return True


class CarteiraPrePaga(MeioDePagamento):
    """Crédito carregado antes. Sem saldo, recusa retornando False (não lança)."""

    def __init__(self, saldo_centavos: int):
        self._saldo = saldo_centavos

    @property
    def saldo(self) -> int:
        return self._saldo

    def cobrar(self, valor_centavos: int, referencia: str) -> bool:
        if valor_centavos > self._saldo:
            return False
        self._saldo -= valor_centavos
        return True

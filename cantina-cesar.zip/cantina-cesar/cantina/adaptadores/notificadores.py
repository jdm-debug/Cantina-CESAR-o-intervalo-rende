from typing import List, Tuple

from ..portas import Notificador


class NotificadorConsole(Notificador):
    def notificar(self, senha: str, mensagem: str) -> None:
        print(f"  🔔 [senha {senha}] {mensagem}")


class NotificadorEmMemoria(Notificador):
    """Usado nos testes: guarda as mensagens para verificação."""

    def __init__(self):
        self.mensagens: List[Tuple[str, str]] = []

    def notificar(self, senha: str, mensagem: str) -> None:
        self.mensagens.append((senha, mensagem))

"""Segregação de Interfaces: o aluno e a cozinha enxergam contratos diferentes.

A tela do aluno não tem acesso a "avancar"; a tela da cozinha
não precisa saber de pagamento.
"""
from abc import ABC, abstractmethod
from typing import Dict, List, Tuple

from .dominio.pedido import Pedido, Status
from .dominio.produto import Produto


class VisaoCliente(ABC):
    @abstractmethod
    def cardapio(self) -> List[Tuple[str, Produto]]: ...

    @abstractmethod
    def fazer_pedido(self, itens: Dict[str, int]) -> Pedido: ...

    @abstractmethod
    def pagar(self, senha: str, meio: str) -> int:
        """Paga e retorna a estimativa de retirada em minutos."""

    @abstractmethod
    def consultar(self, senha: str) -> Tuple[Status, int]: ...


class VisaoCozinha(ABC):
    @abstractmethod
    def fila(self) -> List[Pedido]: ...

    @abstractmethod
    def avancar(self, senha: str) -> Status:
        """Recebido -> em preparo -> pronto -> retirado."""

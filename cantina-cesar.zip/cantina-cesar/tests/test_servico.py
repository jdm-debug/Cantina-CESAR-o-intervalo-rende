import pytest

from cantina.adaptadores.notificadores import NotificadorEmMemoria
from cantina.adaptadores.pagamentos import CarteiraPrePaga, PagamentoPix
from cantina.adaptadores.repositorio_memoria import RepositorioEmMemoria
from cantina.app import cardapio_do_dia
from cantina.dominio.pedido import Status
from cantina.servicos.estimador import EstimadorDeFila
from cantina.servicos.servico_pedidos import PagamentoRecusado, ServicoDePedidos


def montar(meios=None):
    notificador = NotificadorEmMemoria()
    servico = ServicoDePedidos(
        cardapio_do_dia(),
        RepositorioEmMemoria(),
        meios or {"pix": PagamentoPix()},
        notificador,
        EstimadorDeFila(atendentes=1),
    )
    return servico, notificador


def test_fluxo_completo_notifica_pagamento_e_pronto():
    servico, notif = montar()
    pedido = servico.fazer_pedido({"1": 1})
    servico.pagar(pedido.senha, "pix")
    servico.avancar(pedido.senha)
    assert servico.avancar(pedido.senha) is Status.PRONTO
    assert len(notif.mensagens) == 2
    assert "pronto" in notif.mensagens[-1][1]


@pytest.mark.parametrize("meio", [PagamentoPix(), CarteiraPrePaga(10_000)])
def test_liskov_qualquer_meio_de_pagamento_funciona(meio):
    servico, _ = montar({"x": meio})
    pedido = servico.fazer_pedido({"2": 1})
    servico.pagar(pedido.senha, "x")
    assert pedido.status is Status.RECEBIDO


def test_carteira_sem_saldo_recusa_sem_mudar_status():
    servico, _ = montar({"carteira": CarteiraPrePaga(100)})
    pedido = servico.fazer_pedido({"3": 1})
    with pytest.raises(PagamentoRecusado):
        servico.pagar(pedido.senha, "carteira")
    assert pedido.status is Status.AGUARDANDO_PAGAMENTO


def test_estimativa_considera_quem_esta_na_frente():
    servico, _ = montar()
    a = servico.fazer_pedido({"3": 1})  # 5 min
    b = servico.fazer_pedido({"1": 1})  # 3 min
    servico.pagar(a.senha, "pix")
    assert servico.pagar(b.senha, "pix") == 8

import pytest

from cantina.dominio.pedido import Pedido, Status, TransicaoInvalida
from cantina.dominio.produto import Combo, Item

COXINHA = Item("Coxinha", 750, 3)
SUCO = Item("Suco", 600, 1)


def test_combo_soma_precos_com_desconto_e_preparo_em_paralelo():
    combo = Combo("Combo", [COXINHA, SUCO], desconto_centavos=150)
    assert combo.preco() == 1200
    assert combo.tempo_preparo() == 3


def test_combo_e_item_sao_intercambiaveis_no_pedido():
    pedido = Pedido("001", [(COXINHA, 2), (Combo("C", [SUCO]), 1)])
    assert pedido.total() == 750 * 2 + 600


def test_pedido_segue_ciclo_de_vida():
    p = Pedido("001", [(COXINHA, 1)])
    p.confirmar_pagamento()
    p.iniciar_preparo()
    p.marcar_pronto()
    p.retirar()
    assert p.status is Status.RETIRADO


def test_nao_da_para_preparar_pedido_nao_pago():
    p = Pedido("001", [(COXINHA, 1)])
    with pytest.raises(TransicaoInvalida):
        p.iniciar_preparo()


def test_pedido_vazio_ou_quantidade_invalida():
    with pytest.raises(ValueError):
        Pedido("001", [])
    with pytest.raises(ValueError):
        Pedido("001", [(COXINHA, 0)])
